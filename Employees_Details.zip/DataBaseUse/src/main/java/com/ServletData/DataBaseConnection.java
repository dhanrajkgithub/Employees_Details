package com.ServletData;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseConnection {
	 private static final String url="jdbc:mysql://localhost:3306/employeedb";
	  private static final String username="root";
	  private static final String passward="root";
	  
      public static Connection createDBConnection()
      {
    	  Connection con=null;
    	  try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		  } catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		  }
    	  //Create  Connection
    	  try {
    	   con=DriverManager.getConnection(url,username,passward);
    	 
    	  
    	  }
    	  catch(SQLException e)
    	  {
    		  System.out.println(e.getMessage());
    	  }
    	  return con;
    	  
      }
}
