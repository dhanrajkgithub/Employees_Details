package com.Servlet;

import java.io.IOException;
import java.sql.*;

import com.ServletData.DataBaseConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");

		String email = req.getParameter("email");
		String password = req.getParameter("password");  // ✅ fixed

		Connection con = DataBaseConnection.createDBConnection();
		if (con == null) {
			res.getWriter().println("<h4 style='color:red'>Database connection failed</h4>");
			return;
		}

		try {
			PreparedStatement pre = con.prepareStatement("SELECT * FROM emp WHERE email=? AND passward=?");
			pre.setString(1, email);
			pre.setString(2, password);

			ResultSet r = pre.executeQuery();

			if (r.next()) {
				Employee emp = new Employee();
				emp.setId(r.getString("id"));
				emp.setName(r.getString("name"));
				emp.setPassward(r.getString("passward"));
				emp.setEmail(r.getString("email"));
				emp.setGender(r.getString("gender"));
				emp.setCity(r.getString("city"));

				req.setAttribute("Employee", emp);
				req.setAttribute("name", emp.getName());

				// ✅ forward to next JSP (this displays Displayemp.jsp content)
				req.getRequestDispatcher("Displayemp.jsp").forward(req, res);
			} 
			else {
				// ❌ invalid credentials
				req.setAttribute("msg", "Invalid email or password!");
				req.getRequestDispatcher("login.jsp").forward(req, res);
			}
		} 
		catch (SQLException e) {
			e.printStackTrace();
			req.setAttribute("msg", "Database error: " + e.getMessage());
			req.getRequestDispatcher("login.jsp").forward(req, res);
		}
	}
}
