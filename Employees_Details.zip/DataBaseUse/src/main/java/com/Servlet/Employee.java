package com.Servlet;

public class Employee {
	
	private String id;
	private String name;
	private String passward;
	private String email;
	private String gender;
	private String city;
	public Employee()
	{
		
	}
	public Employee(String id, String name, String passward, String email, String gender, String city) {
		super();
		this.id = id;
		this.name = name;
		this.passward = passward;
		this.email = email;
		this.gender = gender;
		this.city = city;
		
		
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassward() {
		return passward;
	}
	public void setPassward(String passward) {
		this.passward = passward;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	

}
