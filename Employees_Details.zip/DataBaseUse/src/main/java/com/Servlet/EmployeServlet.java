package com.Servlet;

import java.io.IOException;
import java.sql.*;

import com.ServletData.DataBaseConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/save")
public class EmployeServlet extends HttpServlet{
	

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		String id=req.getParameter("id");
		String name =req.getParameter("name");
		String email=req.getParameter("email");
		String passward=req.getParameter("passward");
		String gender =req.getParameter("gender");
		String city=req.getParameter("city");
		
	   Connection con=DataBaseConnection.createDBConnection();
	   try
	   {
	   PreparedStatement pre=con.prepareStatement("insert into emp values(?,?,?,?,?,?)");
	   pre.setString(1,id);
	   pre.setString(2,name);
	   pre.setString(3,passward);
	   pre.setString(4,email);
	   pre.setString(5,gender);
	   pre.setString(6,city);
	   
	   int i=pre.executeUpdate();
	   
	   if(i>0)
	   {
		   res.getWriter().print("<h2 style='color:green'>Employee saved Sucessfully</h2>");
			 req.getRequestDispatcher("customer.html").include(req, res);
	   }
	   else
	   {
		 res.getWriter().print("<h2 style='color:red'>Employee failed Sucessfully</h2>");
		 req.getRequestDispatcher("customer.html").include(req, res);
	   }
	   }
	   catch(Exception e)
	   {
		 System.out.println(e.getMessage());
	   }
		
		
	}
}
